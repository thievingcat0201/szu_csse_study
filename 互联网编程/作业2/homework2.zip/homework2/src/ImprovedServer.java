import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.*;

public class ImprovedServer {
    private static final int PORT = 8080;
    private static final ExecutorService threadPool = Executors.newFixedThreadPool(10);
    private static final ConcurrentHashMap<String, String> clientFiles = new ConcurrentHashMap<>();
    private static final Logger logger = LogManager.getLogger(ImprovedServer.class);

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(PORT);
        logger.info("Server started on port {}", PORT);

        // 启动日志分析服务
        LogAnalysisService analysisService = new LogAnalysisService();
        new Thread(analysisService).start();

        while (true) {
            try {
                Socket clientSocket = serverSocket.accept();
                threadPool.execute(new ClientHandler(clientSocket));
            } catch (IOException e) {
                logger.error("Error accepting client connection", e);
            }
        }
    }

    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String clientIP = clientSocket.getInetAddress().getHostAddress();
                String clientFileName = "Client_" + clientIP + ".txt";
                clientFiles.put(clientIP, clientFileName);

                File clientFile = new File(clientFileName);
                if (!clientFile.exists()) {
                    clientFile.createNewFile();
                }

                try (BufferedWriter outToFile = new BufferedWriter(new FileWriter(clientFile, true))) {
                    String message;
                    while ((message = in.readLine()) != null) {
                        outToFile.write(message + "\n");
                        outToFile.flush();
                        logger.info("Received from {}: {}", clientIP, message);
                    }
                }

                String digest = generateDigest(clientFileName);
                logger.info("Digest generated for {}: {}", clientFileName, digest);

                try (BufferedWriter safeOut = new BufferedWriter(new FileWriter("SafeAbstract.txt", true))) {
                    safeOut.write(clientFileName + ": " + digest + "\n");
                }

            } catch (IOException | NoSuchAlgorithmException e) {
                logger.error("Error handling client request", e);
            } finally {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    logger.error("Error closing client socket", e);
                }
            }
        }

        private String generateDigest(String fileName) throws NoSuchAlgorithmException, IOException {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    digest.update(line.getBytes());
                }
            }
            byte[] hashBytes = digest.digest();
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        }
    }

    // 日志分析服务
    static class LogAnalysisService implements Runnable {
        private final Logger analysisLogger = LogManager.getLogger("LogAnalysis");
        private final BlockingQueue<LogTask> logQueue = new LinkedBlockingQueue<>();

        @Override
        public void run() {
            analysisLogger.info("Log analysis service started");
            while (true) {
                try {
                    LogTask task = logQueue.take();
                    processLog(task);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    analysisLogger.error("Error processing log task", e);
                }
            }
        }

        private void processLog(LogTask task) {
            // 实现日志分析逻辑
            analysisLogger.info("Processing log: {}", task.getMessage());
            // 这里可以添加更复杂的分析逻辑
        }

        public void addLogTask(LogTask task) {
            logQueue.offer(task);
        }
    }

    static class LogTask {
        private final String message;
        private final long timestamp;

        public LogTask(String message) {
            this.message = message;
            this.timestamp = System.currentTimeMillis();
        }

        public String getMessage() {
            return message;
        }

        public long getTimestamp() {
            return timestamp;
        }
    }
}