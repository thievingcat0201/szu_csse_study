import java.io.*;
import java.net.*;

public class TCPClient {
    private static final String SERVER_IP = "localhost";
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) {
        try (
                Socket socket = new Socket(SERVER_IP, SERVER_PORT);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in))
        ) {
            System.out.println("已连接到服务器");
            System.out.println("请输入要发送的消息(输入'exit'退出):");

            String userInputLine;
            while ((userInputLine = userInput.readLine()) != null) {
                if ("exit".equalsIgnoreCase(userInputLine)) {
                    break;
                }

                System.out.println("发送: " + userInputLine);
                out.println(userInputLine);

                String response = in.readLine();
                System.out.println( response);

                System.out.println("请输入下一消息(输入'exit'退出):");
            }

            System.out.println("客户端退出");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}