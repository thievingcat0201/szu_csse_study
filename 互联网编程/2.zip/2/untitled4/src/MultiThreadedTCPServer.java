import java.io.*;
import java.net.*;

public class MultiThreadedTCPServer {
    private static final int PORT = 12345;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("多线程TCP服务器启动，监听端口: " + PORT);
            System.out.println("等待客户端连接...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("客户端连接: " + clientSocket.getInetAddress().getHostAddress());

                // 为每个客户端创建一个新线程
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class ClientHandler extends Thread {
    private Socket clientSocket;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    public void run() {
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println("收到客户端消息: " + inputLine);

                // 简单处理：将消息转为大写并返回
                String response = "服务器响应: " + inputLine.toUpperCase();
                out.println(response);
                System.out.println("发送响应: " + response);
            }
        } catch (IOException e) {
            System.out.println("客户端连接异常: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
                System.out.println("客户端连接关闭");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}