import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ConcurrentHashMap;

public class Server {
    private static final int PORT = 8080;
    private static final String LOG_FILE = "ServerLog.log";
    private static final String SAFE_ABSTRACT_FILE = "SafeAbstract.txt";
    private static final ExecutorService threadPool = Executors.newFixedThreadPool(10);
    private static final ConcurrentHashMap<String, String> clientFiles = new ConcurrentHashMap<>();

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(PORT);
        System.out.println("Server is running...");

        while (true) {
            Socket clientSocket = serverSocket.accept();
            threadPool.execute(new ClientHandler(clientSocket));
        }
    }

    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String clientIP = clientSocket.getInetAddress().getHostAddress();
                String clientFileName = "Client_" + clientIP + ".txt";
                clientFiles.put(clientIP, clientFileName);

                File clientFile = new File(clientFileName);
                if (!clientFile.exists()) {
                    clientFile.createNewFile();
                }

                BufferedWriter outToFile = new BufferedWriter(new FileWriter(clientFile, true));

                String message;
                while ((message = in.readLine()) != null) {
                    outToFile.write(message + "\n");
                    outToFile.flush();
                    log("Received message from " + clientIP + ": " + message);
                }

                outToFile.close();
                in.close();
                clientSocket.close();

                String digest = generateDigest(clientFileName);
                log("Generated digest for " + clientFileName + ": " + digest);

                try (BufferedWriter safeOut = new BufferedWriter(new FileWriter(SAFE_ABSTRACT_FILE, true))) {
                    safeOut.write(clientFileName + ": " + digest + "\n");
                }

            } catch (IOException | NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }

        private void log(String message) {
            try (BufferedWriter logWriter = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
                logWriter.write(message + "\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private String generateDigest(String fileName) throws NoSuchAlgorithmException, IOException {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    digest.update(line.getBytes());
                }
            }
            byte[] hashBytes = digest.digest();
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        }
    }
}