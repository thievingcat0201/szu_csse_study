import java.io.*;
import java.net.*;
import java.nio.file.*;

public class UDPClient {
    private static final int CLIENT_PORT = 8888;
    private static final int SERVER_PORT = 9999;
    private static final String CLIENT_DATA_FILE = "ClientData.txt";

    public static void main(String[] args) {
        try (DatagramSocket clientSocket = new DatagramSocket(CLIENT_PORT)) {
            System.out.println("客户端已启动，监听端口: " + CLIENT_PORT);

            // 初始化输出文件
            Path outPath = Paths.get(System.getProperty("user.dir"), CLIENT_DATA_FILE);
            Files.writeString(outPath, "");

            int lineNumber = 1;
            InetAddress serverAddress = InetAddress.getByName("localhost");

            while (true) {
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                clientSocket.receive(receivePacket);
                String receivedLine = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("[客户端] " + receivedLine);

                String processedLine = lineNumber + ": " + receivedLine;
                Files.writeString(outPath, processedLine + "\n", StandardOpenOption.APPEND);

                byte[] sendData = processedLine.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(
                        sendData, sendData.length, serverAddress, SERVER_PORT);
                clientSocket.send(sendPacket);

                lineNumber++;
            }
        } catch (IOException e) {
            System.err.println("客户端错误: " + e.getMessage());
        }
    }
}