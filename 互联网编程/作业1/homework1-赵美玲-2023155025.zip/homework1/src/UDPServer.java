import java.io.*;
import java.net.*;
import java.nio.file.*;

public class UDPServer {
    private static final int SERVER_PORT = 9999;
    private static final int CLIENT_PORT = 8888;
    private static final String SERVER_DATA_FILE = "ServerData.txt";

    public static void main(String[] args) {
        try (DatagramSocket serverSocket = new DatagramSocket(SERVER_PORT)) {
            System.out.println("服务器已启动，监听端口: " + SERVER_PORT);

            // 读取文件内容（使用绝对路径更可靠）
            Path filePath = Paths.get(System.getProperty("user.dir"), SERVER_DATA_FILE);
            String content = Files.readString(filePath);
            String[] lines = content.split("\n");

            InetAddress clientAddress = InetAddress.getByName("localhost");

            for (String line : lines) {
                line = line.trim();
                if (!line.isEmpty()) {
                    byte[] sendData = line.getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(
                            sendData, sendData.length, clientAddress, CLIENT_PORT);
                    serverSocket.send(sendPacket);
                    System.out.println("[服务器] 已发送: " + line);

                    byte[] receiveData = new byte[1024];
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    serverSocket.receive(receivePacket);
                    String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    System.out.println("[服务器] 收到回应: " + response);
                }
            }
        } catch (IOException e) {
            System.err.println("服务器错误: " + e.getMessage());
        }
    }
}