package src;

import java.io.*;
import java.net.Socket ;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random ;
import java.util.Scanner;
import java.util.SimpleTimeZone;

public class Client implements Runnable {
    private static final int PORT=9982;
    private int pos;
    private Socket socket;
    private StringBuilder path_sin = new StringBuilder("src/client");
    private StringBuilder path_in = new StringBuilder("src/client_resourse");
    private StringBuilder head = new StringBuilder("");
    private FileOutputStream fw;
    private BufferedOutputStream output;
    private BufferedInputStream in;
    private BufferedOutputStream out;
    private final String[] type1 = {"GET", "HEAD", "POST"};
    private final String[] type2 = {"file2.jpg", "file1.js", "file1.html"};
    private Random rd = new Random();
    private String receivedCookie;
    Client(int p) {
        pos = p;
    }

    public void run() {
        try {
            int y1 = rd.nextInt(3);
            int y2 = rd.nextInt(3);
            if (y1 == 0) {
                path_in.append("/" + pos + "" + type2[y2]);
                fw = new FileOutputStream(path_in.toString());
                output = new BufferedOutputStream(fw);
            } else {
                path_in.append("/" + pos + ".txt");
                fw = new FileOutputStream(path_in.toString());
                output = new BufferedOutputStream(fw);
            }
            socket = new Socket("localhost", PORT);
            in = new BufferedInputStream(socket.getInputStream());
            out = new BufferedOutputStream(socket.getOutputStream());
            System.out.println(pos);
            head.append(type1[y1]);
            head.append(" "+type2[y2]+" HTTP/1.1\n\n");
            out.write(head.toString().getBytes());
            out.flush();
            System.out.println(pos+":"+type1[y1]+" "+type2[y2]);
            byte[]byffer=new byte[4096];
            int len;
            while((len=in.read(byffer))>0){
              output.write(byffer,0,len);
              output.flush();
            }
            output.close();
           /* byte[] buffer = new byte[4096];
            boolean isHeader = true;
            StringBuilder headerBuilder = new StringBuilder();

            while ((len = in.read(buffer)) > 0) {
                if (isHeader) {
                    String response = new String(buffer, 0, len);
                    headerBuilder.append(response);
                    int endIndex = headerBuilder.indexOf("\r\n\r\n");
                    if (endIndex != -1) {
                        isHeader = false;
                        String header = headerBuilder.substring(0, endIndex);
                        processHeader(header);
                        output.write(response.getBytes(), endIndex + 4, len - (endIndex + 4));
                    }
                } else {
                    output.write(buffer, 0, len);
                }
                output.flush();
            }

            output.close();
            socket.close();*/


            ///////////////////////////////////////////////////////////////////

            path_sin.append("/"+pos+".txt");
            System.out.println(path_sin.toString());
            FileWriter fileWriter=new FileWriter(path_sin.toString());
            BufferedWriter bufferedWriter=new BufferedWriter(fileWriter);
            Scanner sin=new Scanner(in);
            String t;
            StringBuilder temp1=new StringBuilder(" ");
            while (sin.hasNextLine() && !(t = sin.nextLine()).isEmpty()) {
                System.out.println("WORKING");
                temp1.append(t).append("\r\n");
            }
            bufferedWriter.write(temp1.toString(),0,temp1.length());
            bufferedWriter.flush();
            bufferedWriter.close();
            ////////////////////////////////////////////////////////

          /*  System.out.println(pos+":"+type1[y1]+" "+type2[y2]);
            // 接收响应体
            byte[] buffer = new byte[4096];
            int len;
            while ((len = in.read(buffer)) > 0) {
                output.write(buffer, 0, len);
                output.flush();
            }
       //     saveCookieToFile(pos,cookie);
            output.close();
            socket.close();*/
            /*   Scanner sin = new Scanner(in);
            String t;
            StringBuilder temp = new StringBuilder("");
            while (sin.hasNextLine() && !(t = sin.nextLine()).isEmpty()) {
                temp.append(t).append("\r\n");
            }

            // 将响应头写入文件
            String path_sin = "src/client_data/" + pos + ".txt";
            FileWriter sfw = new FileWriter(path_sin);
            BufferedWriter soutput = new BufferedWriter(sfw);
            soutput.write(temp.toString());
            soutput.flush();
            soutput.close();*/
        } catch (IOException e) {
            System.out.println("Unable to connect to the server");
        }
    }
    private void processHeader(String header) {
        String[] lines = header.split("\r\n");
        for (String line : lines) {
            if (line.startsWith("Set-Cookie:")) {
                receivedCookie = line.substring(line.indexOf(":") + 1).trim();
                saveCookieToFile(pos, receivedCookie);
            }
        }
    }

    private void saveCookieToFile(int clientId, String cookie) {
        try {
            path_sin.append("/"+pos+".txt");
            File file = new File("client");
            FileWriter fileWriter = new FileWriter(file, true);
            BufferedWriter writer = new BufferedWriter(fileWriter);
            Scanner scanner=new Scanner(in);
            String str;
            StringBuilder stringBuilder=new StringBuilder("");
            while((str=scanner.nextLine())!=null&&str.length()!=0){
                stringBuilder.append(str);
            }
            writer.newLine();
            writer.flush();
            writer.close();
        } catch (IOException e) {
            System.out.println("src.Client " + clientId + " - Unable to save cookie to file");
        }
    }
}

