package src;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class HttpServer {
    public final static int THREAD_COUNT = 20;
    public final static int PORT=9982;

    public static void main(String []args) throws IOException {
        ExecutorService pool = Executors.newFixedThreadPool(THREAD_COUNT);
        ServerSocket serverSocket = new ServerSocket(PORT);
        int i = 1;

        while (true) {
            Socket clientSocket = serverSocket.accept();
            Runnable task = new Handle(clientSocket, i);
            pool.submit(task);
            System.out.println(i);
            i++;
        }
    }
}
