import java.net.URL;
import java.util.Scanner;

public class URLDecomposer {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 输入URL
        System.out.println("请输入一个URL：");
        String urlString = scanner.nextLine();

        // 调用方法分解URL
        decomposeURL(urlString);

        scanner.close();
    }

    public static void decomposeURL(String urlString) {
        try {
            // 创建URL对象
            URL url = new URL(urlString);

            // 提取URL的各组成部分
            String protocol = url.getProtocol(); // 协议
            String host = url.getHost();         // 主机名或IP地址
            int port = url.getPort();            // 端口号
            String path = url.getPath();         // 路径
            String query = url.getQuery();       // 查询参数
            String ref = url.getRef();           // 锚点

            // 输出URL的各组成部分
            System.out.println("URL分解结果：");
            System.out.println("协议: " + protocol);
            System.out.println("主机: " + host);
            System.out.println("端口: " + (port != -1 ? port : "默认端口"));
            System.out.println("路径: " + path);
            System.out.println("查询参数: " + (query != null ? query : "无查询参数"));
            System.out.println("锚点: " + (ref != null ? ref : "无锚点"));
        } catch (Exception e) {
            System.out.println("输入的URL格式不正确，请检查！");
        }
    }
}