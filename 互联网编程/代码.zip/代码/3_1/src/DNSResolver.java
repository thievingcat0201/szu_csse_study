import java.net.*;
import java.util.Scanner;

public class DNSResolver {
    // 域名→IP解析
    public static String resolveDomain(String domain) {
        try {
            InetAddress[] addresses = InetAddress.getAllByName(domain);
            StringBuilder sb = new StringBuilder();
            for (InetAddress addr : addresses) {
                sb.append(addr.getHostAddress()).append("\n");
            }
            return sb.toString().trim();
        } catch (UnknownHostException e) {
            return "解析失败: " + e.getMessage();
        }
    }

    // IP→域名反向解析
    public static String reverseDNS(String ip) {
        try {
            InetAddress addr = InetAddress.getByName(ip);
            String hostname = addr.getHostName();
            return hostname.equals(ip) ? "无反向解析记录" : hostname;
        } catch (UnknownHostException e) {
            return "反向解析失败: " + e.getMessage();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("请输入域名进行解析：");
        String domain = scanner.nextLine();
        System.out.println("域名解析结果：");
        System.out.println(domain + " → " + resolveDomain(domain));

        System.out.println("\n请输入IP地址进行反向解析：");
        String ip = scanner.nextLine();
        System.out.println("反向解析结果：");
        System.out.println(ip + " → " + reverseDNS(ip));

        scanner.close();
    }
}