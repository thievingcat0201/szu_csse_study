import java.io.*;
import java.net.*;
import java.util.Scanner;

public class WebPageDownloader {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 输入网页的URL
        System.out.println("请输入网页的URL：");
        String urlString = scanner.nextLine();

        // 输入保存文件的路径
        System.out.println("请输入保存网页内容的本地路径：");
        String filePath = scanner.nextLine();

        // 调用方法下载网页内容并保存
        downloadWebPage(urlString, filePath);

        scanner.close();
    }

    public static void downloadWebPage(String urlString, String filePath) {
        try {
            // 检查文件路径是否存在，如果不存在则创建父目录
            File file = new File(filePath);
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs(); // 创建父目录
            }

            // 创建URL对象
            URL url = new URL(urlString);

            // 打开连接并获取输入流
            InputStream inputStream = url.openStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            // 创建文件输出流
            FileOutputStream fileOutputStream = new FileOutputStream(filePath);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fileOutputStream));

            // 逐行读取网页内容并写入文件
            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.newLine();
            }

            // 关闭资源
            writer.close();
            fileOutputStream.close();
            reader.close();
            inputStream.close();

            System.out.println("网页内容已成功保存到：" + filePath);
        } catch (MalformedURLException e) {
            System.out.println("输入的URL格式不正确，请检查！");
        } catch (IOException e) {
            System.out.println("下载网页时发生错误：" + e.getMessage());
        }
    }
}