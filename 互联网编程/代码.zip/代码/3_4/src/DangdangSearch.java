import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class DangdangSearch {
    public static void main(String[] args) {
        // 提示用户输入搜索关键词
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.println("请输入搜索关键词：");
        String keyword = scanner.nextLine();

        // 构造搜索请求的URL
        String searchUrl = "http://search.dangdang.com/?key=" + keyword;

        // 创建HttpClient并启用自动重定向
        HttpClient client = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL) // 启用自动重定向
                .build();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(searchUrl))
                .build();

        try {
            // 发送请求并获取响应
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // 获取响应体（HTML源码）
            String htmlContent = response.body();

            // 保存HTML源码到文件
            String filePath = "productResult.html";
            saveToFile(htmlContent, filePath);



            System.out.println("搜索结果已保存到文件：" + filePath);
        } catch (Exception e) {
            System.out.println("发生错误：" + e.getMessage());
        }
    }

    public static void saveToFile(String content, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(content);
        } catch (IOException e) {
            System.out.println("保存文件时发生错误：" + e.getMessage());
        }
    }
}