import heapq  # 优先队列（堆）
import copy


def manhattan_distance(state, goal_map):
    distance = 0
    for i in range(len(state)):
        for j in range(len(state[0])):
            value = state[i][j]
            if value != 0:
                goal_pos = goal_map[value]
                distance += abs(i - goal_pos[0]) + abs(j - goal_pos[1])

    return distance


def index_mapping_2d(lst):
    index_map = {}
    for i in range(len(lst)):
        for j in range(len(lst[i])):
            val = lst[i][j]
            index_map[val] = (i, j)
    return index_map


def find_element_in_2d_list(arr, target):
    for i in range(len(arr)):
        for j in range(len(arr[i])):
            if arr[i][j] == target:
                return i, j
    return None


def AStar(initial_state, goal_state):

    goal_map = index_mapping_2d(goal_state)
    frontier = []  # 待探索节点（边界），以空的优先队列实现，成本低的先探索
    heapq.heappush(frontier, (0, initial_state))
    came_from = dict()  # 记录每个节点的前驱节点
    min_cost = dict()  # 记录目前位置探索过的节点的最小成本
    initial_state_tuple = tuple(map(tuple, initial_state))
    came_from[initial_state_tuple] = None  # 起始状态的前驱状态设置为0
    min_cost[initial_state_tuple] = 0  # 到达起始状态的成本设置为0
    zero_move_direcs = [[-1, 0], [1, 0], [0, -1], [0, 1]]  # 0的移动方向
    while frontier:  # 进行探索，直到 frontier 中没有待探索的状态
        _, current = heapq.heappop(frontier)  # 探索优先级最高的状态
        if current == goal_state:
            break
        # 遍历当前状态的相邻状态
        current_state_tuple = tuple(map(tuple, current))  # 当前状态转为tuple以便哈希
        x_zero, y_zero = find_element_in_2d_list(current, 0)  # 找到0所在位置
        for direc in zero_move_direcs:
            # 计算下一个状态0所在的位置
            new_x_zero = x_zero + direc[0]
            new_y_zero = y_zero + direc[1]
            # 检查该状态0的位置是否合法
            if new_x_zero < 0 or new_y_zero < 0 or new_x_zero >= len(initial_state) or new_y_zero >= len(
                    initial_state[0]):
                continue
            # 计算从起始状态到next状态的成本，这里由于0不管往哪个方向移动成本都一致，所以next状态成本直接+1即可
            new_cost = min_cost[current_state_tuple] + 1
            next = copy.deepcopy(current)
            # 将0移动到下一个状态的位置
            next[new_x_zero][new_y_zero], next[x_zero][y_zero] = next[x_zero][y_zero], next[new_x_zero][new_y_zero]
            next_state_tuple = tuple(map(tuple, next))
            if next_state_tuple not in min_cost or new_cost < min_cost[next_state_tuple]:
                # 更新next状态的成本
                min_cost[next_state_tuple] = new_cost
                # 使用曼哈顿距离计算next的启发式估计成本（initial到next的准确成本 + next到goal的估计成本）
                priority_cost = new_cost + manhattan_distance(next, goal_map)
                # 将next状态以计算出的启发式估计成本加入优先队列中
                heapq.heappush(frontier, (priority_cost, next))
                came_from[next_state_tuple] = tuple(map(tuple, current))
    return came_from


def build_path(initial_state, goal_state, came_from):

    # 将二维列表转换为元组
    initial_state_tuple = tuple(map(tuple, initial_state))
    goal_state_tuple = tuple(map(tuple, goal_state))
    current_tuple = goal_state_tuple
    path = []
    have_solution = True

    # 回溯找到路径
    while current_tuple != initial_state_tuple:
        if goal_state_tuple not in came_from:
            have_solution = False
            print("无解")
            break
        else:
            path.append(current_tuple)
            current_tuple = came_from[current_tuple]

    # 如果有解，则输出路径
    if have_solution:
        path.append(initial_state_tuple)
        path.reverse()
        step = 0
        for state in path:
            print("步骤" + str(step))
            step += 1
            for row in state:
                print(row)
            print()


initial_state = [
   [1, 2, 6],
    [4, 5, 8],
    [7, 0, 3]
]

goal_state = [
    [1, 2, 3],
    [4, 5, 6],
    [ 7, 8,0]
]

# 使用A*算法求解路径
came_from = AStar(initial_state, goal_state)
# 进行路径构建
build_path(initial_state, goal_state, came_from)
