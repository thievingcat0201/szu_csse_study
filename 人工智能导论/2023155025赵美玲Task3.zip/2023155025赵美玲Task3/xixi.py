import numpy as np
import matplotlib.pyplot as plt

# 创建k臂老虎机问题
def k_abd(k):
    q_mean = np.random.normal(0, 1, k)  # 为每个臂生成一个均值为0，标准差为1的正态分布随机数
    return q_mean

# 进行游戏
def play(epsilon, q_mean):
    k = len(q_mean)  # 老虎机的臂数
    reward = []  # 存储每一步的累积平均奖励
    total_reward = 0  # 累积总奖励
    optimal_action_percentage = []  # 存储每一步选择最优臂的百分比
    N = np.zeros(k)  # 每个臂被选择的次数
    Q = np.zeros(k)  # 每个臂的估计值
    optimal_action = 0  # 选择最优臂的次数
    optimal_index = np.argmax(q_mean)  # 计算最优臂的索引，只计算一次
    for i in range(2000):  # 进行2000步游戏
        # 基于ε-贪心策略选择臂
        if np.random.rand() < epsilon:
            A = np.random.randint(k)  # 随机选择一个臂
        else:
            A = np.argmax(Q)  # 选择估计值最高的臂
        if A == optimal_index:
            optimal_action += 1  # 如果选择了最优臂，则计数增加
        R = np.random.normal(q_mean[A], 1)  # 生成一个正态分布的奖励
        N[A] += 1  # 更新选择次数
        Q[A] += (R - Q[A]) / N[A]  # 更新估计值
        total_reward += R  # 更新总奖励
        reward.append(total_reward / (i + 1))  # 计算并存储累积平均奖励
        optimal_action_percentage.append(optimal_action / (i + 1))  # 计算并存储选择最优臂的百分比
    return reward, optimal_action_percentage

k = 10  # 设置老虎机的臂数为10
armed_bandit_10 = k_abd(k)  # 创建10臂老虎机
r1, qap1 = play(0, armed_bandit_10)  # 以ε=0进行游戏
r2, qap2 = play(0.01, armed_bandit_10)  # 以ε=0.01进行游戏
r3, qap3 = play(0.1, armed_bandit_10)  # 以ε=0.1进行游戏

# 绘制平均奖励图
plt.figure(figsize=(10, 5), dpi=150)
plt.plot(r1, label='ε=0')  # 绘制ε=0时的平均奖励曲线
plt.plot(r2, label='ε=0.01')  # 绘制ε=0.01时的平均奖励曲线
plt.plot(r3, label='ε=0.1')  # 绘制ε=0.1时的平均奖励曲线
plt.legend()  # 显示图例
plt.xlabel('Steps')
plt.ylabel('Average Reward')
plt.title('10-armed bandit problem')
plt.show()

# 绘制选择最优臂的百分比图
plt.figure(figsize=(10, 5), dpi=150)
plt.plot(qap1, label='ε=0')  # 绘制ε=0时选择最优臂的百分比曲线
plt.plot(qap2, label='ε=0.01')  # 绘制ε=0.01时选择最优臂的百分比曲线
plt.plot(qap3, label='ε=0.1')  # 绘制ε=0.1时选择最优臂的百分比曲线
plt.legend()  # 显示图例
plt.xlabel('Steps')
plt.ylabel('% Optimal Action')
plt.title('10-armed bandit problem')
plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter(1))  # 设置y轴的显示格式为百分比
plt.show()  # 显示图表