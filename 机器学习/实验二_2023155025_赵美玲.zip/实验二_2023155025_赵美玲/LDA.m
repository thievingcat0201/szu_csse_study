%% 多算法人脸识别性能比较（AR数据集）
clear; clc; close all;
warning('off', 'images:imshow:magnificationMustBeFitForDockedFigure');

%% ===================== 数据准备 =====================
data_path = 'C:\Users\27419\Desktop\AR_Gray_50by40\';
img_size = [50, 40];
target_persons = 1:50; % 使用前50人进行测试
samples_per_person = 20;
train_samples = 14; % 每人训练样本数

% 加载数据
[X, y, raw_imgs] = load_ar_data(data_path, target_persons, img_size);
fprintf('成功加载%d类共%d张图像\n', length(target_persons), size(X,1));

% 数据划分（每人前6测试，后14训练）
[train_idx, test_idx] = split_data(y, target_persons, samples_per_person-train_samples, train_samples);
X_train = X(train_idx,:); y_train = y(train_idx);
X_test = X(test_idx,:); y_test = y(test_idx);

% 转换为2D图像格式（用于2DPCA/2DLDA）
train_imgs = reshape(X_train', [img_size, 1, size(X_train,1)]);
test_imgs = reshape(X_test', [img_size, 1, size(X_test,1)]);

%% ===================== 算法性能比较 =====================
methods = {'PCA', '2DPCA', 'LDA', '2DLDA', 'MMC'};
accuracies = zeros(length(methods), 1);
training_times = zeros(length(methods), 1);

% 1. PCA
tic;
[pca_coeff, pca_score] = pca(X_train, 'NumComponents', 100);
pca_time = toc;
pca_proj_test = X_test * pca_coeff;
accuracies(1) = evaluate_accuracy(pca_score, y_train, pca_proj_test, y_test);
training_times(1) = pca_time;

% 2. 2DPCA
tic;
[W_2dpca, ~] = TwoDPCA(train_imgs, 10); % 取10个投影向量
train_2dpca = project_2dpca(train_imgs, W_2dpca);
test_2dpca = project_2dpca(test_imgs, W_2dpca);
accuracies(2) = evaluate_accuracy(train_2dpca, y_train, test_2dpca, y_test);
training_times(2) = toc;

% 3. LDA
tic;
[lda_coeff, lda_proj] = lda(X_train, y_train, 50); % 最多50维
lda_proj_test = X_test * lda_coeff;
accuracies(3) = evaluate_accuracy(lda_proj, y_train, lda_proj_test, y_test);
training_times(3) = toc;

% 4. 2DLDA
tic;
[W_2dlda, ~] = TwoDLDA(train_imgs, y_train, 10); % 取10个投影向量
train_2dlda = project_2dlda(train_imgs, W_2dlda);
test_2dlda = project_2dlda(test_imgs, W_2dlda);
accuracies(4) = evaluate_accuracy(train_2dlda, y_train, test_2dlda, y_test);
training_times(4) = toc;

% 5. MMC
tic;
[mmc_coeff, ~] = mmc(X_train, y_train, 50); % 最多50维
mmc_proj = X_train * mmc_coeff;
mmc_proj_test = X_test * mmc_coeff;
accuracies(5) = evaluate_accuracy(mmc_proj, y_train, mmc_proj_test, y_test);
training_times(5) = toc;

%% ===================== 结果可视化 =====================
% 1. 准确率比较
figure('Position', [100,100,800,400]);
bar(accuracies * 100);
set(gca, 'XTickLabel', methods, 'FontSize', 12);
ylabel('识别准确率(%)');
title('不同算法在AR数据集上的性能比较');
grid on;

% 添加准确率标签
for i = 1:length(accuracies)
    text(i, accuracies(i)*100+1, sprintf('%.1f%%', accuracies(i)*100), ...
        'HorizontalAlignment', 'center', 'FontSize', 12);
end

% 2. 训练时间比较
figure('Position', [100,100,800,400]);
bar(training_times);
set(gca, 'XTickLabel', methods, 'FontSize', 12, 'YScale', 'log');
ylabel('训练时间(秒, log尺度)');
title('不同算法的训练时间比较');
grid on;

% 添加时间标签
for i = 1:length(training_times)
    text(i, training_times(i)*1.2, sprintf('%.2fs', training_times(i)), ...
        'HorizontalAlignment', 'center', 'FontSize', 12);
end

%% ===================== 子函数定义 =====================
function [X, y, raw_imgs] = load_ar_data(data_path, target_persons, img_size)
    X = []; y = []; raw_imgs = {};
    for i = target_persons
        for j = 1:20
            try
                if i < 10
                    img = imread(fullfile(data_path, sprintf('AR00%d-%d.tif', i, j)));
                else
                    img = imread(fullfile(data_path, sprintf('AR0%d-%d.tif', i, j)));
                end
                X = [X; double(img(:))'];
                y = [y; i];
                raw_imgs{end+1} = img;
            catch
                fprintf('缺失文件: 人员%02d 样本%d\n', i, j);
            end
        end
    end
    y = y(:);
end

function [train_idx, test_idx] = split_data(y, target_persons, n_test, n_train)
    train_idx = false(size(y));
    test_idx = false(size(y));
    for p = target_persons
        samples = find(y == p);
        test_idx(samples(1:min(n_test,end))) = true;
        if length(samples) > n_test
            train_idx(samples(n_test+1:min(n_test+n_train,end))) = true;
        end
    end
end

function accuracy = evaluate_accuracy(train_proj, y_train, test_proj, y_test)
    % KNN分类（k=3）
    mdl = fitcknn(train_proj, y_train, 'NumNeighbors', 3);
    y_pred = predict(mdl, test_proj);
    accuracy = sum(y_pred == y_test) / numel(y_test);
end

function [W, projected] = TwoDPCA(images, k)
    % 2DPCA实现
    [h, w, ~, n] = size(images);
    G = zeros(w, w);
    
    % 计算图像协方差矩阵
    mean_img = mean(images, 4);
    for i = 1:n
        temp = double(images(:,:,:,i)) - mean_img;
        G = G + temp' * temp;
    end
    G = G / n;
    
    % 特征分解
    [V, D] = eig(G);
    [~, idx] = sort(diag(D), 'descend');
    W = V(:, idx(1:k));
    
    % 投影计算
    projected = zeros(n, h*k);
    for i = 1:n
        temp = double(images(:,:,:,i)) * W;
        projected(i,:) = temp(:)';
    end
end

function projected = project_2dpca(images, W)
    % 2DPCA投影
    [h, ~, ~, n] = size(images);
    k = size(W,2);
    projected = zeros(n, h*k);
    for i = 1:n
        temp = double(images(:,:,:,i)) * W;
        projected(i,:) = temp(:)';
    end
end

function [W, projected] = TwoDLDA(images, labels, k)
    % 2DLDA实现
    [h, w, ~, n] = size(images);
    classes = unique(labels);
    nc = length(classes);
    
    % 计算类内和类间散度
    mean_total = mean(images, 4);
    Sw = zeros(w, w);
    Sb = zeros(w, w);
    
    for c = 1:nc
        class_imgs = images(:,:,:,labels==classes(c));
        mean_class = mean(class_imgs, 4);
        n_class = size(class_imgs, 4);
        
        % 类内散度
        for i = 1:n_class
            temp = double(class_imgs(:,:,:,i)) - mean_class;
            Sw = Sw + temp' * temp;
        end
        
        % 类间散度
        temp = mean_class - mean_total;
        Sb = Sb + n_class * (temp' * temp);
    end
    
    % 正则化
    Sw = Sw + 1e-6 * eye(size(Sw));
    
    % 求解广义特征问题
    [V, D] = eig(Sb, Sw);
    [~, idx] = sort(diag(D), 'descend');
    W = V(:, idx(1:k));
    
    % 投影计算
    projected = zeros(n, h*k);
    for i = 1:n
        temp = double(images(:,:,:,i)) * W;
        projected(i,:) = temp(:)';
    end
end

function projected = project_2dlda(images, W)
    % 2DLDA投影
    [h, ~, ~, n] = size(images);
    k = size(W,2);
    projected = zeros(n, h*k);
    for i = 1:n
        temp = double(images(:,:,:,i)) * W;
        projected(i,:) = temp(:)';
    end
end

function [W, proj] = lda(X, y, max_dim)
    % LDA实现
    classes = unique(y);
    nc = length(classes);
    mean_total = mean(X, 1);
    Sw = zeros(size(X,2));
    Sb = zeros(size(X,2));
    
    for c = 1:nc
        class_data = X(y==classes(c),:);
        mean_class = mean(class_data, 1);
        n_class = size(class_data, 1);
        
        % 类内散度
        Sw = Sw + (class_data - mean_class)' * (class_data - mean_class);
        
        % 类间散度
        Sb = Sb + n_class * (mean_class - mean_total)' * (mean_class - mean_total);
    end
    
    % 正则化
    Sw = Sw + 1e-6 * eye(size(Sw));
    
    % 特征分解
    [V, D] = eig(Sb, Sw);
    [~, idx] = sort(diag(D), 'descend');
    valid = idx(diag(D(idx)) > 1e-6);
    W = V(:, idx(valid(1:min(end,max_dim))));
    
    proj = X * W;
end

function [W, proj] = mmc(X, y, max_dim)
    % MMC (Maximum Margin Criterion)实现
    classes = unique(y);
    nc = length(classes);
    mean_total = mean(X, 1);
    St = cov(X) * (size(X,1)-1); % 总散度
    
    Sb = zeros(size(X,2));
    for c = 1:nc
        class_data = X(y==classes(c),:);
        mean_class = mean(class_data, 1);
        n_class = size(class_data, 1);
        Sb = Sb + n_class * (mean_class - mean_total)' * (mean_class - mean_total);
    end
    
    % MMC目标矩阵
    M = Sb - St;
    
    % 特征分解
    [V, D] = eig(M);
    [~, idx] = sort(diag(D), 'descend');
    W = V(:, idx(1:max_dim));
    
    proj = X * W;
end