%% AR人脸数据集LDA分析（修正图例警告版）
clear; clc; close all;
warning('off', 'images:imshow:magnificationMustBeFitForDockedFigure');

%% ===================== 数据加载 =====================
data_path = 'C:\Users\27419\Desktop\AR_Gray_50by40\';
img_size = [50, 40];
target_persons = [1, 33, 66]; % 选择3个类别
samples_per_person = 20;

% 加载数据
[X, y, raw_images] = load_ar_data(data_path, target_persons, img_size);
fprintf('成功加载%d类共%d张图像\n', length(target_persons), size(X,1));

%% ===================== 数据划分 =====================
[train_idx, test_idx] = split_data(y, target_persons, 6, 14);

X_train = X(train_idx,:);
y_train = y(train_idx);
raw_train = raw_images(train_idx);
X_test = X(test_idx,:);
y_test = y(test_idx);

fprintf('实际训练样本数/类: %s\n', mat2str(arrayfun(@(p) sum(y_train==p), target_persons)));

%% ===================== 两阶段降维 =====================
[coeff_pca, score_train] = perform_pca(X_train, 0.95);
lda = train_lda(score_train, y_train);
W_combined = coeff_pca(:,1:size(score_train,2)) * (lda.Sigma \ (lda.Mu(2:end,:) - lda.Mu(1,:))');

%% ===================== 可视化 =====================
% 1. 人脸重构演示
show_reconstruction(X_train, y_train, raw_train, W_combined, img_size, target_persons);

% 2. 二维投影（带人脸缩略图）
plot_2d_projection(X, y, raw_images, W_combined, target_persons);

% 3. 三维投影（如果可用）
if size(W_combined,2) >= 3
    plot_3d_projection(X, y, raw_images, W_combined, target_persons);
end

%% ===================== 子函数定义 =====================
function [X, y, raw_images] = load_ar_data(data_path, target_persons, img_size)
    X = []; y = []; raw_images = {};
    for i = target_persons
        for j = 1:20
            try
                if i < 10
                    img = imread(fullfile(data_path, sprintf('AR00%d-%d.tif', i, j)));
                else
                    img = imread(fullfile(data_path, sprintf('AR0%d-%d.tif', i, j)));
                end
                X = [X; double(img(:))'];
                y = [y; i];
                raw_images{end+1} = img;
            catch
                fprintf('缺失文件: 人员%02d 样本%d\n', i, j);
            end
        end
    end
    y = y(:);
end

function [train_idx, test_idx] = split_data(y, target_persons, n_test, n_train)
    train_idx = false(size(y));
    test_idx = false(size(y));
    for p = target_persons
        samples = find(y == p);
        test_idx(samples(1:min(n_test,end))) = true;
        if length(samples) > n_test
            train_idx(samples(n_test+1:min(n_test+n_train,end))) = true;
        end
    end
end

function [coeff, score] = perform_pca(X, var_explained)
    [coeff, score, ~, ~, explained] = pca(X);
    cum_var = cumsum(explained)./sum(explained);
    pca_dim = find(cum_var >= var_explained, 1);
    if isempty(pca_dim)
        pca_dim = size(score,2);
        warning('无法达到%.1f%%方差，使用全部%d维', var_explained*100, pca_dim);
    else
        fprintf('PCA降维到%d维（保留%.1f%%方差）\n', pca_dim, cum_var(pca_dim)*100);
    end
    score = score(:,1:pca_dim);
end

function lda = train_lda(X, y)
    max_retry = 3;
    for k = 1:max_retry
        try
            lda = fitcdiscr(X, y, 'DiscrimType', 'pseudolinear', 'Gamma', 0.3);
            return;
        catch ME
            fprintf('LDA训练错误(%d/%d): %s\n', k, max_retry, ME.message);
            if k < max_retry
                new_dim = max(1, floor(size(X,2)*0.8));
                fprintf('尝试减小维度到%d...\n', new_dim);
                X = X(:,1:new_dim);
            else
                error('LDA训练失败');
            end
        end
    end
end

function show_reconstruction(X_train, y_train, raw_train, W, img_size, target_persons)
    recon_dims = [1, 2, 5, 10, 20, size(W,2)];
    samples_per_class = 3; % 每类显示3个样本
    total_rows = length(target_persons)*samples_per_class;
    total_cols = length(recon_dims) + 1;
    
    figure('Name', 'LDA人脸重构', 'Position', [100,100,1500,900]);
    
    for class_idx = 1:length(target_persons)
        class_samples = find(y_train == target_persons(class_idx));
        display_samples = class_samples(1:min(samples_per_class, length(class_samples)));
        
        for sample_idx = 1:length(display_samples)
            idx = display_samples(sample_idx);
            row = (class_idx-1)*samples_per_class + sample_idx;
            
            % 原始图像
            subplot(total_rows, total_cols, (row-1)*total_cols + 1);
            imshow(raw_train{idx});
            if sample_idx == 1
                title(sprintf('Person %d\n原始', y_train(idx)));
            else
                title('原始');
            end
            
            % 重构图像
            for d = 1:length(recon_dims)
                dim = min(recon_dims(d), size(W,2));
                proj = X_train(idx,:) * W(:,1:dim);
                recon = W(:,1:dim) * proj' + mean(X_train)';
                
                subplot(total_rows, total_cols, (row-1)*total_cols + d + 1);
                imshow(uint8(reshape(recon, img_size)));
                if sample_idx == 1 && d == ceil(length(recon_dims)/2)
                    title('不同维度重构结果');
                end
            end
        end
    end
end

function plot_2d_projection(X, y, raw_images, W, target_persons)
    X_proj = X * W(:,1:2);
    
    figure('Name', 'LDA二维投影', 'Position', [100,100,1000,800]);
    hold on;
    colors = lines(length(target_persons));
    
    % 绘制散点（确保每组数据点数量一致）
    h = zeros(1, length(target_persons));
    for i = 1:length(target_persons)
        mask = (y == target_persons(i));
        if any(mask)
            h(i) = scatter(X_proj(mask,1), X_proj(mask,2), ...
                50, colors(i,:), 'filled', ...
                'DisplayName', sprintf('Person %d', target_persons(i)));
        end
    end
    
    % 移除空句柄
    h = h(h ~= 0);
    
    % 标注代表样本（每类最多3个）
    marker_samples = [];
    for p = target_persons
        samples = find(y == p);
        marker_samples = [marker_samples; samples(1:min(3,end))];
    end
    
    % 创建缩略图轴
    thumb_pos = linspace(0.7, 0.1, length(marker_samples));
    for i = 1:length(marker_samples)
        idx = marker_samples(i);
        
        % 绘制标记点
        plot(X_proj(idx,1), X_proj(idx,2), 'ko', 'MarkerSize', 12, 'LineWidth', 2);
        
        % 创建缩略图
        ax = axes('Position', [0.7 thumb_pos(i) 0.2 0.2]);
        imshow(raw_images{idx});
        title(sprintf('P%d-S%d', y(idx), find(y==y(idx),1)));
        axis off;
    end
    
    % 添加图例（仅显示有效条目）
    if ~isempty(h)
        legend(h, 'Location', 'bestoutside');
    end
    title('LDA二维投影（带样本缩略图）');
    xlabel('第一判别方向'); ylabel('第二判别方向');
    grid on;
end

function plot_3d_projection(X, y, raw_images, W, target_persons)
    X_proj = X * W(:,1:3);
    
    figure('Name', 'LDA三维投影', 'Position', [100,100,1000,800]);
    hold on;
    colors = lines(length(target_persons));
    
    % 绘制散点（确保每组数据点数量一致）
    h = zeros(1, length(target_persons));
    for i = 1:length(target_persons)
        mask = (y == target_persons(i));
        if any(mask)
            h(i) = scatter3(X_proj(mask,1), X_proj(mask,2), X_proj(mask,3), ...
                50, colors(i,:), 'filled', ...
                'DisplayName', sprintf('Person %d', target_persons(i)));
        end
    end
    
    % 移除空句柄
    h = h(h ~= 0);
    
    % 标注代表样本
    marker_samples = [];
    for p = target_persons
        samples = find(y == p);
        marker_samples = [marker_samples; samples(1:min(3,end))];
    end
    
    % 添加缩略图
    for i = 1:length(target_persons)
        ax = axes('Position', [0.8 0.8-(i-1)*0.2 0.15 0.15]);
        sample_idx = find(y == target_persons(i),1);
        imshow(raw_images{sample_idx});
        title(sprintf('P%d代表', target_persons(i)));
        axis off;
    end
    
    % 添加图例（仅显示有效条目）
    if ~isempty(h)
        legend(h, 'Location', 'bestoutside');
    end
    title('LDA三维投影空间');
    xlabel('LD1'); ylabel('LD2'); zlabel('LD3');
    grid on;
    view(3);
    rotate3d on;
end