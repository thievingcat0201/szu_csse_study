% 主脚本部分
clear; clc; close all;
set(0,'DefaultFigureWindowStyle','docked'); % 停靠图形窗口方便查看

%% 第一部分：人脸图像聚类实验
disp('=== 人脸图像聚类实验 ===');
face_folder = 'C:\Users\27419\Desktop\AR_Gray_50by40';
[face_data, face_labels, face_imgs] = load_face_data(face_folder, 3); % 加载前3个人的人脸

% 数据处理
face_data = zscore(face_data);
[~, face_score] = pca(face_data);
face_2d = face_score(:, 1:2);

% 测试不同K值
face_ks = 2:5;
face_results = run_clustering_experiment(face_2d, face_labels, face_imgs, face_ks, '人脸数据集');

%% 第二部分：COIL20旋转物体聚类实验
disp('=== COIL20旋转物体聚类实验 ===');
coil_folder = 'C:\Users\27419\Desktop\coil-20-proc';
[coil_data, coil_labels, coil_imgs] = load_coil_data(coil_folder, 3); % 加载前3类物体

% 数据处理
coil_data = zscore(coil_data);
[~, coil_score] = pca(coil_data);
coil_2d = coil_score(:, 1:2);

% 测试不同K值
coil_ks = 2:5;
coil_results = run_clustering_experiment(coil_2d, coil_labels, coil_imgs, coil_ks, 'COIL20数据集');

%% 显示精度结果表格
disp(' ');
disp('聚类精度结果汇总:');
result_table = table(...
    face_results.ks', face_results.accuracies'*100, ...
    coil_results.ks', coil_results.accuracies'*100, ...
    'VariableNames', {'人脸_K值', '人脸精度(%)', 'COIL20_K值', 'COIL20精度(%)'});
disp(result_table);

% ========== 函数定义部分 ==========

function [data, labels, imgs] = load_face_data(folder, num_persons)
    % 加载前num_persons个人的人脸图像
    data = []; labels = []; imgs = {};
    for person = 1:num_persons
        [images, img_cells] = load_images_from_folder(folder, person, 26, 'AR%03d-%d.tif');
        data = [data; images];
        labels = [labels; repmat(person, size(images, 1), 1)];
        imgs = [imgs; img_cells];
    end
end

function [data, labels, imgs] = load_coil_data(folder, num_classes)
    % 加载COIL20数据集前num_classes类物体
    data = []; labels = []; imgs = {};
    for class_id = 1:num_classes
        [images, img_cells] = load_images_from_folder(folder, class_id, 72, 'obj%d__%d.png', 0);
        data = [data; images];
        labels = [labels; repmat(class_id, size(images, 1), 1)];
        imgs = [imgs; img_cells];
    end
end

function [images, img_cells] = load_images_from_folder(folder, class_id, num_images, filename_pattern, start_idx)
    % 返回图像数据和图像单元数组
    if nargin < 5
        start_idx = 1; % 默认从1开始编号
    end
    
    images = [];
    img_cells = {};
    for img_num = start_idx:(start_idx + num_images - 1)
        img_path = fullfile(folder, sprintf(filename_pattern, class_id, img_num));
        if exist(img_path, 'file')
            img = imread(img_path);
            if size(img, 3) == 3
                img = rgb2gray(img);
            end
            img_resized = imresize(img, [50, 40]); % 统一尺寸
            images = [images; double(img_resized(:)')];
            img_cells{end+1} = img_resized;
        else
            warning('图像不存在: %s', img_path);
        end
    end
end

function results = run_clustering_experiment(data_2d, true_labels, imgs, ks, dataset_name)
    % 运行完整聚类实验流程
    results.ks = ks;
    results.accuracies = zeros(size(ks));
    
    fig = figure('Position', [100, 100, 1200, 800], 'Color', 'w');
    tiledlayout(length(ks), 1, 'TileSpacing', 'tight', 'Padding', 'tight');
    
    for i = 1:length(ks)
        k = ks(i);
        [cluster_model, idx] = perform_kmeans(data_2d, k);
        acc = calculate_aligned_accuracy(true_labels, idx);
        results.accuracies(i) = acc;
        
        % 绘制聚类结果
        nexttile;
        plot_cluster_results(data_2d, true_labels, idx, imgs, cluster_model, k, dataset_name);
        
        fprintf('%s - k=%d: 精度=%.2f%%\n', dataset_name, k, acc*100);
    end
    sgtitle(sprintf('%s - 不同K值聚类结果', dataset_name), 'FontSize', 12, 'FontWeight', 'bold');
end

function plot_cluster_results(data, true_labels, cluster_labels, imgs, cluster_model, k, dataset_name)
    % 增强的聚类结果可视化，包含图像缩略图
    
    % 创建颜色和符号映射
    true_colors = lines(max(true_labels));
    cluster_symbols = {'o', 's', '^', 'd', 'v', '>', '<', 'p', 'h'};
    marker_size = 8;
    
    % 绘制所有点（透明，只为建立坐标系）
    scatter(data(:, 1), data(:, 2), 1, 'w', 'filled');
    hold on;
    axis equal;
    grid on;
    
    % 计算显示缩略图的位置偏移量
    data_range = range(data);
    img_offset = data_range * 0.05;
    
    % 绘制每个数据点
    for i = 1:size(data, 1)
        % 绘制数据点（不同聚类用不同符号）
        marker = cluster_symbols{mod(cluster_labels(i)-1, length(cluster_symbols))+1};
        scatter(data(i, 1), data(i, 2), 60, ...
               true_colors(true_labels(i), :), ...
               'filled', ...
               'Marker', marker, ...
               'MarkerEdgeColor', 'k', ...
               'LineWidth', 0.5);
        
        % 在点旁边显示图像缩略图
        if mod(i,3) == 0 % 为避免重叠，只显示部分图像
            img_pos = [data(i, 1)+img_offset(1), data(i, 2)-img_offset(2)];
            image('XData', [img_pos(1), img_pos(1)+img_offset(1)], ...
                  'YData', [img_pos(2)+img_offset(2), img_pos(2)], ...
                  'CData', imgs{i}, ...
                  'AlphaData', 0.7);
        end
    end
    
    % 绘制聚类中心
    centers = cluster_model.cluster_centers_;
    plot(centers(:, 1), centers(:, 2), 'kx', 'MarkerSize', 12, 'LineWidth', 2);
    
    % 添加标签和标题
    xlabel('PCA Component 1');
    ylabel('PCA Component 2');
    title(sprintf('K=%d (精度: %.2f%%)', k, ...
          calculate_aligned_accuracy(true_labels, cluster_labels)*100), ...
          'FontSize', 10);
    
    % 创建图例
    h_true = [];
    unique_true = unique(true_labels);
    for i = 1:length(unique_true)
        h_true(i) = scatter(NaN, NaN, 60, true_colors(i, :), 'filled', 'DisplayName', sprintf('类别%d', unique_true(i)));
    end
    
    h_cluster = [];
    unique_cluster = unique(cluster_labels);
    for i = 1:min(length(unique_cluster), length(cluster_symbols))
        h_cluster(i) = scatter(NaN, NaN, 60, 'k', cluster_symbols{i}, 'LineWidth', 1, ...
                              'DisplayName', sprintf('聚类%d', unique_cluster(i)));
    end
    
    legend([h_true, h_cluster], 'Location', 'bestoutside');
    hold off;
end

function [cluster_model, idx] = perform_kmeans(data, k)
    rng(42); % 固定随机种子
    [idx, centers] = kmeans(data, k, 'Replicates', 10, 'MaxIter', 1000);
    cluster_model.labels_ = idx;
    cluster_model.cluster_centers_ = centers;
end

function acc = calculate_aligned_accuracy(true_labels, pred_labels)
    % 解决标签排列问题后的精度计算
    C = confusionmat(true_labels, pred_labels);
    [~, assignment] = max(C, [], 2);
    remapped_pred = zeros(size(pred_labels));
    for i = 1:length(assignment)
        remapped_pred(pred_labels == assignment(i)) = i;
    end
    acc = sum(remapped_pred == true_labels) / length(true_labels);
end