%% AR人脸数据集LDA分析（已验证版本）
clear; clc; close all;
warning('off', 'images:imshow:magnificationMustBeFitForDockedFigure');

%% ===================== 数据加载验证 =====================
data_path = 'C:\Users\27419\Desktop\AR_Gray_50by40\';
if ~isfolder(d ...
        ...
        ata_path)
    error('数据集路径不存在，请检查路径: %s', data_path);
end

img_size = [50, 40];  % 严格匹配您的数据尺寸
num_persons = 99;     % AR数据集实际可用人数
samples_per_person = 20;

% 预分配并验证图像尺寸
file_list = dir(fullfile(data_path, 'AR*.tif'));
if isempty(file_list)
    error('未找到AR图像文件，请检查文件命名规则');
end

% 样本完整性检查
valid_persons = [];
for i = 1:num_persons
    missing_count = 0;
    for j = 1:samples_per_person
        if i < 10
            fname = sprintf('AR00%d-%d.tif', i, j);
        else
            fname = sprintf('AR0%d-%d.tif', i, j);
        end
        if ~isfile(fullfile(data_path, fname))
            missing_count = missing_count + 1;
        end
    end
    if missing_count == 0
        valid_persons = [valid_persons, i];
    else
        fprintf('人员%02d缺失%d个样本，已排除\n', i, missing_count);
    end
end
num_valid_persons = length(valid_persons);

% 加载有效数据
reshaped_faces = zeros(prod(img_size), num_valid_persons*samples_per_person);
person_ids = zeros(1, num_valid_persons*samples_per_person);
sample_nums = zeros(1, num_valid_persons*samples_per_person);

count = 0;
for p = 1:num_valid_persons
    i = valid_persons(p);
    for j = 1:samples_per_person
        count = count + 1;
        if i < 10
            img = imread(fullfile(data_path, sprintf('AR00%d-%d.tif', i, j)));
        else
            img = imread(fullfile(data_path, sprintf('AR0%d-%d.tif', i, j)));
        end
        
        % 尺寸验证
        if ~isequal(size(img), img_size)
            error('图像尺寸不符: 人员%02d 样本%d', i, j);
        end
        
        reshaped_faces(:, count) = double(img(:));
        person_ids(count) = i;
        sample_nums(count) = j;
    end
end
fprintf('成功加载%d个人的%d张图像\n', num_valid_persons, count);

%% ===================== 数据划分（严格前6后14） =====================
train_idx = [];
test_idx = [];
for p = 1:num_valid_persons
    person_mask = (person_ids == valid_persons(p));
    person_samples = find(person_mask);
    
    % 确保样本连续编号
    if ~isequal(sample_nums(person_samples), 1:samples_per_person)
        error('人员%02d的样本编号不连续', valid_persons(p));
    end
    
    test_idx = [test_idx, person_samples(1:6)];
    train_idx = [train_idx, person_samples(7:end)];
end

train_data = reshaped_faces(:, train_idx);
test_data = reshaped_faces(:, test_idx);
labels_train = person_ids(train_idx);
labels_test = person_ids(test_idx);

%% ===================== LDA核心算法（带验证） =====================
% 均值计算验证
mean_total = mean(train_data, 2);
if any(isnan(mean_total))
    error('均值计算出现NaN值');
end

% 散度矩阵计算
Sw = zeros(prod(img_size));
Sb = zeros(prod(img_size));
for i = 1:num_valid_persons
    class_mask = (labels_train == valid_persons(i));
    if sum(class_mask) < 2
        error('人员%02d训练样本不足', valid_persons(i));
    end
    
    class_data = train_data(:, class_mask);
    mean_class = mean(class_data, 2);
    
    % 类内散度
    Sw = Sw + (class_data - mean_class) * (class_data - mean_class)';
    
    % 类间散度
    Sb = Sb + sum(class_mask) * (mean_class - mean_total) * (mean_class - mean_total)';
end

% 矩阵条件数检查
fprintf('Sw条件数: %.2e\n', cond(Sw));
fprintf('Sb条件数: %.2e\n', cond(Sb));

% 正则化处理
reg_param = 1e-5;
Sw_reg = Sw + reg_param * eye(size(Sw));
fprintf('正则化后Sw条件数: %.2e\n', cond(Sw_reg));

% 特征分解
[V, D] = eig(Sb, Sw_reg);
eigenvalues = diag(D);
[~, idx] = sort(eigenvalues, 'descend');
valid_idx = eigenvalues(idx) > 1e-6;
W = V(:, idx(valid_idx));

fprintf('获得%d个有效判别方向\n', size(W,2));

%% ===================== 可视化（带异常检测） =====================
% 1. 投影方向可视化
figure('Name', 'LDA投影方向', 'Position', [100,100,1200,400]);
try
    subplot(1,3,1);
    imshow(reshape(mean_total, img_size), []);
    title('平均人脸');
    
    subplot(1,3,2);
    lda_dir1 = reshape(W(:,1), img_size);
    imshow(lda_dir1, [min(lda_dir1(:)), max(lda_dir1(:))]);
    title('第一判别方向');
    
    subplot(1,3,3);
    lda_dir2 = reshape(W(:,2), img_size);
    imshow(lda_dir2, [min(lda_dir2(:)), max(lda_dir2(:))]);
    title('第二判别方向');
catch ME
    fprintf('可视化错误: %s\n', ME.message);
end

% 2. 二维投影（限制显示类别数量）
show_classes = min(10, num_valid_persons);
figure('Name', 'LDA二维投影', 'Position', [100,100,800,600]);
hold on;
colors = lines(show_classes);

for i = 1:show_classes
    class_mask = (labels_train == valid_persons(i));
    if sum(class_mask) == 0
        continue;
    end
    
    proj = W(:,1:2)' * (train_data(:,class_mask) - mean_total);
    if size(proj,2) < 1
        continue;
    end
    
    scatter(proj(1,:), proj(2,:), 30, colors(i,:), 'filled', ...
           'DisplayName', sprintf('Person %d', valid_persons(i)));
end

title('LDA二维投影空间');
xlabel('第一判别方向'); ylabel('第二判别方向');
legend('Location', 'bestoutside');
grid on;

%% ===================== 识别测试（带交叉验证） =====================
max_dim = min(50, size(W,2));
knn_k = 3;

% 数据投影
proj_train = W(:,1:max_dim)' * (train_data - mean_total);
proj_test = W(:,1:max_dim)' * (test_data - mean_total);

% KNN分类（带距离校验）
try
    dist_mat = pdist2(proj_test', proj_train');
    [~, idx] = mink(dist_mat, knn_k, 2);
    predicted = mode(labels_train(idx), 2);
    
    % 计算指标
    accuracy = mean(predicted == labels_test');
    fprintf('识别准确率: %.2f%%\n', accuracy*100);
    
    % 混淆矩阵
    figure;
    confusionchart(labels_test, predicted);
    title(sprintf('混淆矩阵 (准确率: %.1f%%)', accuracy*100));
catch ME
    fprintf('分类错误: %s\n', ME.message);
end

%% ===================== 重构质量评估 =====================
demo_persons = valid_persons(round(linspace(1, num_valid_persons, 3)));
recon_dims = [1, 2, 5, 10, 20, 30];

figure('Name', 'LDA人脸重构', 'Position', [100,100,1200,600]);
for p = 1:length(demo_persons)
    sample_idx = find(labels_train == demo_persons(p), 1);
    if isempty(sample_idx)
        continue;
    end
    
    original = reshape(train_data(:,sample_idx), img_size);
    subplot(3, length(recon_dims)+1, (p-1)*(length(recon_dims)+1)+1);
    imshow(original, []);
    title(sprintf('Person %d\n原始', demo_persons(p)));
    
    for d = 1:length(recon_dims)
        dim = min(recon_dims(d), size(W,2));
        proj = W(:,1:dim)' * (train_data(:,sample_idx) - mean_total);
        recon = W(:,1:dim) * proj + mean_total;
        
        subplot(3, length(recon_dims)+1, (p-1)*(length(recon_dims)+1)+d+1);
        imshow(reshape(recon, img_size), []);
        title(sprintf('Dim=%d', dim));
        
        % 计算重构误差
        if d == length(recon_dims)
            rmse = sqrt(mean((recon - train_data(:,sample_idx)).^2));
            fprintf('人员%d最终重构RMSE: %.2f\n', demo_persons(p), rmse);
        end
    end
end