%% 二维SVM支持向量可视化完整代码
clear; clc; close all;

rng(42); % 设置随机种子保证可重复性

% 生成两个高斯分布的类别
class1 = mvnrnd([1, 1], [0.3 0; 0 0.3], 50);   % 类别1 (标签+1)
class2 = mvnrnd([-1, -1], [0.3 0; 0 0.3], 50); % 类别2 (标签-1)

% 合并数据集
X = [class1; class2];          % 特征矩阵
y = [ones(50,1); -ones(50,1)]; % 标签向量

SVMModel = fitcsvm(X, y, ...
    'KernelFunction', 'linear', ...
    'BoxConstraint', 1, ...
    'Standardize', false, ...
    'Solver', 'SMO');

% 提取模型参数
w = SVMModel.Beta;              % 权重向量
b = SVMModel.Bias;              % 偏置项
sv = SVMModel.SupportVectors;   % 支持向量
sv_idx = SVMModel.IsSupportVector; % 支持向量索引

figure('Position', [100, 100, 800, 600]);
hold on;
grid on;
axis equal;

% 1. 绘制原始数据点
h_pos = scatter(class1(:,1), class1(:,2), 80, 'r', 'filled', 'o');
h_neg = scatter(class2(:,1), class2(:,2), 80, 'b', 'filled', 'o');

% 2. 标记支持向量
h_sv = scatter(sv(:,1), sv(:,2), 150, 'y', 'filled', 'o');
h_sv_outline = plot(sv(:,1), sv(:,2), 'ko', 'MarkerSize', 10, 'LineWidth', 1.5);

% 3. 计算并绘制决策边界
x_lim = [min(X(:,1))-0.5, max(X(:,1))+0.5];
x_plot = linspace(x_lim(1), x_lim(2), 100);
y_decision = (-w(1)*x_plot - b)/w(2);
h_decision = plot(x_plot, y_decision, 'k-', 'LineWidth', 2);

% 4. 绘制间隔边界
margin = 1/sqrt(sum(w.^2));
y_upper = y_decision + margin;
y_lower = y_decision - margin;
h_margin1 = plot(x_plot, y_upper, 'k--', 'LineWidth', 1.5);
h_margin2 = plot(x_plot, y_lower, 'k--', 'LineWidth', 1.5);

% 5. 填充间隔区域
h_fill = fill([x_plot, fliplr(x_plot)], [y_upper, fliplr(y_lower)], ...
             [0.9 0.9 0.9], 'FaceAlpha', 0.3, 'EdgeColor', 'none');

% 设置坐标轴范围
xlim(x_lim);
ylim([min(X(:,2))-0.5, max(X(:,2))+0.5]);

% 添加标签和标题
xlabel('特征1', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('特征2', 'FontSize', 12, 'FontWeight', 'bold');
title('二维SVM支持向量可视化', 'FontSize', 14, 'FontWeight', 'bold');

% 添加图例
legend([h_pos, h_neg, h_sv_outline, h_decision, h_margin1], ...
    {'类别 +1', '类别 -1', '支持向量', '决策边界', '间隔边界'}, ...
    'Location', 'northwest', 'FontSize', 10);

% 添加模型信息标注
info_str = sprintf('权重: [%.2f, %.2f]\n偏置: %.2f\n支持向量数: %d', ...
                  w(1), w(2), b, size(sv,1));
annotation('textbox', [0.15, 0.7, 0.2, 0.15], ...
           'String', info_str, ...
           'FitBoxToText', 'on', ...
           'BackgroundColor', 'white', ...
           'FontSize', 10);

hold off;

% 保存图像（可选）
% print('svm_visualization', '-dpng', '-r300');

% 显示支持向量索引
disp('支持向量在原数据集中的索引：');
disp(find(sv_idx));