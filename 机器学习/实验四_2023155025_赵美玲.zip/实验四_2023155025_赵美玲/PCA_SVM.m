clear; clc; close all;

%% 1. 数据加载与预处理
data_path = 'C:\Users\27419\Desktop\AR_Gray_50by40\';
img_size = [50, 40]; % 图像原始尺寸
people_num = 40;      % 人数
pic_num_per_person = 10; % 每人图像数
train_ratio = 0.7;    % 训练集比例

% 加载图像数据
[reshaped_faces, labels] = load_face_data(data_path, people_num, pic_num_per_person, img_size);

% 划分训练测试集
[train_data, test_data, train_labels, test_labels] = ...
    split_dataset(reshaped_faces, labels, people_num, pic_num_per_person, train_ratio);

%% 2. 特征提取（PCA/LDA）
% 数据标准化
all_mean = mean(train_data, 2);
centered_train = train_data - all_mean;
centered_test = test_data - all_mean;

% PCA特征提取
cov_matrix = centered_train * centered_train' / size(centered_train, 2);
[eigen_vectors_pca, eigen_values_pca] = eig(cov_matrix);
eigen_values_pca = diag(eigen_values_pca);
[~, idx] = sort(eigen_values_pca, 'descend');
eigen_vectors_pca = eigen_vectors_pca(:, idx);

% LDA特征提取
[class_mean, Sb, Sw] = calculate_lda_params(train_data, people_num, pic_num_per_person*train_ratio);
target_lda = pinv(Sw) * Sb;
[eigen_vectors_lda, eigen_values_lda] = eig(target_lda);
eigen_values_lda = diag(eigen_values_lda);
[~, idx] = sort(abs(eigen_values_lda), 'descend');
eigen_vectors_lda = eigen_vectors_lda(:, idx);

%% 3. 降维与SVM分类
dims = 10:10:160;
pca_rates = zeros(size(dims));
lda_rates = zeros(size(dims));

for i = 1:length(dims)
    dim = dims(i);
    
    % PCA降维
    proj_matrix_pca = eigen_vectors_pca(:, 1:dim);
    train_pca = proj_matrix_pca' * centered_train;
    test_pca = proj_matrix_pca' * centered_test;
    
    % LDA降维（最多C-1维）
    lda_dim = min(dim, people_num-1);
    proj_matrix_lda = eigen_vectors_lda(:, 1:lda_dim);
    train_lda = proj_matrix_lda' * centered_train;
    test_lda = proj_matrix_lda' * centered_test;
    
    % SVM分类（使用MATLAB内置多分类SVM）
    % PCA+SVM
    svm_model_pca = fitcecoc(train_pca', train_labels);
    pred_pca = predict(svm_model_pca, test_pca');
    pca_rates(i) = sum(pred_pca == test_labels) / length(test_labels);
    
    % LDA+SVM
    svm_model_lda = fitcecoc(train_lda', train_labels);
    pred_lda = predict(svm_model_lda, test_lda');
    lda_rates(i) = sum(pred_lda == test_labels) / length(test_labels);
    
    fprintf('维度 %3d: PCA准确率=%.2f%%, LDA准确率=%.2f%%\n', ...
            dim, pca_rates(i)*100, lda_rates(i)*100);
end

%% 4. 结果可视化
plot_results(dims, pca_rates, lda_rates);

%% ========== 子函数定义 ==========
function [reshaped_faces, labels] = load_face_data(data_path, people_num, pic_num_per_person, img_size)
    % 加载人脸数据
    reshaped_faces = [];
    labels = [];
    for i = 1:people_num
        for j = 1:pic_num_per_person
            if i < 10
                img_name = sprintf('AR00%d-%d.tif', i, j);
            else
                img_name = sprintf('AR0%d-%d.tif', i, j);
            end
            img = imread(fullfile(data_path, img_name));
            img_vec = double(img(:)); % 转换为列向量
            reshaped_faces = [reshaped_faces, img_vec];
            labels = [labels; i]; % 添加标签
        end
    end
end

function [train_data, test_data, train_labels, test_labels] = ...
    split_dataset(data, labels, people_num, pic_num_per_person, train_ratio)
    % 划分训练测试集
    train_num = round(pic_num_per_person * train_ratio);
    train_idx = [];
    test_idx = [];
    
    for i = 0:people_num-1
        start_idx = i*pic_num_per_person + 1;
        train_idx = [train_idx, start_idx:start_idx+train_num-1];
        test_idx = [test_idx, start_idx+train_num:start_idx+pic_num_per_person-1];
    end
    
    train_data = data(:, train_idx);
    test_data = data(:, test_idx);
    train_labels = labels(train_idx);
    test_labels = labels(test_idx);
end

function [class_mean, Sb, Sw] = calculate_lda_params(data, people_num, train_num_per_person)
    % 计算LDA参数
    dimension = size(data, 1);
    class_mean = zeros(dimension, people_num);
    all_mean = mean(data, 2);
    
    % 计算类均值
    for i = 1:people_num
        start_idx = (i-1)*train_num_per_person + 1;
        end_idx = i*train_num_per_person;
        class_mean(:,i) = mean(data(:, start_idx:end_idx), 2);
    end
    
    % 计算Sb
    Sb = zeros(dimension);
    for i = 1:people_num
        diff = class_mean(:,i) - all_mean;
        Sb = Sb + diff * diff';
    end
    Sb = Sb / people_num;
    
    % 计算Sw
    Sw = zeros(dimension);
    for i = 1:people_num
        start_idx = (i-1)*train_num_per_person + 1;
        end_idx = i*train_num_per_person;
        class_data = data(:, start_idx:end_idx);
        centered_data = class_data - class_mean(:,i);
        Sw = Sw + centered_data * centered_data';
    end
    Sw = Sw / (people_num * train_num_per_person);
end

function plot_results(dims, pca_rates, lda_rates)
    % 绘制结果曲线
    figure;
    plot(dims, pca_rates*100, 'b-o', 'LineWidth', 2, 'MarkerFaceColor', 'b');
    hold on;
    plot(dims, lda_rates*100, 'r-s', 'LineWidth', 2, 'MarkerFaceColor', 'r');
    xlabel('特征维度');
    ylabel('分类准确率(%)');
    title('不同特征维度下PCA与LDA性能对比');
    legend('PCA + SVM', 'LDA + SVM', 'Location', 'southeast');
    grid on;
    set(gca, 'FontSize', 12);
    
    % 标注最佳结果
    [best_pca, idx_pca] = max(pca_rates);
    [best_lda, idx_lda] = max(lda_rates);
    text(dims(idx_pca), best_pca*100, sprintf('PCA最佳: %.1f%%', best_pca*100), ...
        'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
    text(dims(idx_lda), best_lda*100, sprintf('LDA最佳: %.1f%%', best_lda*100), ...
        'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left');
end