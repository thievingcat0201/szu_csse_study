%% 初始化
clear; clc;
reshaped_faces = []; % 创建一个矩阵

%% 加载数据
for i = 1:99 % 循环多少人
    for j = 1:20 % 每人多少个样本
        if (i < 10) % 输入图片自动转化为矩阵
            a = imread(strcat('C:\Users\27419\Desktop\AR_Gray_50by40\AR00', num2str(i), '-', num2str(j), '.tif')); % 构建图像地址
        else
            a = imread(strcat('C:\Users\27419\Desktop\AR_Gray_50by40\AR0', num2str(i), '-', num2str(j), '.tif'));
        end
        b = reshape(a, 2000, 1); % 将每一张照片对应矩阵拉成列
        b = double(b); % 转换为 double 类型
        reshaped_faces = [reshaped_faces, b]; % 将循环中的 b 全部输入新矩阵中
    end
end

%% 划分训练集和测试集
test = []; % 定义测试数据组
train = []; % 定义训练数据组
for i = 0:99
    test = [test, 10 * i + 1:10 * i + 6]; % 提取每一张人脸前六张作为测试
    train = [train, 10 * i + 7:10 * i + 14]; % 提取每一张人脸的后14张作为训练
end
train_data = reshaped_faces(:, train); % 训练数据
test_data = reshaped_faces(:, test); % 测试数据

%% 求均值和中心化
mean_face = mean(train_data, 2); % 求训练脸的平均
centered_face = (train_data - mean_face); % 每一张脸减去平均脸

%% PCA 降维
cov_matrix = centered_face * centered_face'; % 求协方差矩阵
[eigen_vectors, dianogol_matrix] = eig(cov_matrix); % 特征向量和特征值
eigen_values = diag(dianogol_matrix); % 提取特征值
[sorted_eigen_values, index] = sort(eigen_values, 'descend'); % 按降序排序
sorted_eigen_vectors = eigen_vectors(:, index); % 排序后的特征向量
all_eigen_faces = sorted_eigen_vectors; % 所有特征脸

%% 任务 1：PCA 人脸重构（重构三个人的图像）
selected_faces = [1, 20, 40]; % 选择三个不同的人脸索引（例如第1、第20、第40个人）
figure;

for person_idx = 1:length(selected_faces)
    single_face = centered_face(:, selected_faces(person_idx)); % 取出选定的人脸
    index = 1; % 索引
    for dimensionality = 20:20:160 % 以20维度开始向160逐渐增加
        eigen_faces = all_eigen_faces(:, 1:dimensionality); % 取前 dimensionality 个特征向量
        rebuild_face = eigen_faces * (eigen_faces' * single_face) + mean_face; % 重构人脸
        subplot(3, 8, (person_idx - 1) * 8 + index); % 三行四列
        index = index + 1; % 依次增大索引
        imshow(uint8(reshape(rebuild_face, 50, 40))); % 展示照片
        title(sprintf("%d", dimensionality)); % 标题
    end
end

%% 任务 2：PCA 人脸识别
% 人脸识别
Y = []; % 保存识别率
for k = 1:6 % 设置 k 值
    for i = 10:10:160 % 测试不同维度
        eigen_faces = all_eigen_faces(:, 1:i); % 取前 i 个特征向量
        projected_train_data = eigen_faces' * (train_data - mean_face); % 训练数据降维
        projected_test_data = eigen_faces' * (test_data - mean_face); % 测试数据降维

        % KNN 分类
        correct_predict_number = 0;
        for each_test_face_index = 1:size(projected_test_data, 2)
            distances = vecnorm(projected_train_data - projected_test_data(:, each_test_face_index)); % 计算距离
            [~, sorted_indices] = sort(distances); % 排序
            predict_label = mode(floor((train(sorted_indices(1:k)) - 1) / 10) + 1); % 预测标签
            real_label = floor((test(each_test_face_index) - 1) / 10) + 1; % 真实标签
            if predict_label == real_label
                correct_predict_number = correct_predict_number + 1;
            end
        end
        correct_rate = correct_predict_number / size(projected_test_data, 2); % 计算识别率
        Y = [Y, correct_rate]; % 保存识别率
    end
end

% 将 Y 重塑为 16x6 的矩阵
Y = reshape(Y, 16, 6);

% 绘制识别率变化曲线图
figure;
hold on;
for k = 1:6
    plot(10:10:160, Y(:, k), '-o', 'DisplayName', sprintf('k=%d', k));
end
xlabel('维度');
ylabel('识别率');
title('不同维度下的识别率变化曲线');
legend show;
grid on;
hold off;
%% 任务 3：PCA 降维后的二维和三维可视化
% 二维可视化
eigen_faces_2d = all_eigen_faces(:, 1:2); % 取前2个特征向量
projected_data_2d = eigen_faces_2d' * (train_data - mean_face); % 二维降维
figure;
scatter(projected_data_2d(1, :), projected_data_2d(2, :), 10, floor((train - 1) / 10) + 1, 'filled');
xlabel('PC1');
ylabel('PC2');
title('二维可视化');
colorbar;

% 三维可视化
eigen_faces_3d = all_eigen_faces(:, 1:3); % 取前3个特征向量
projected_data_3d = eigen_faces_3d' * (train_data - mean_face); % 三维降维
figure;
scatter3(projected_data_3d(1, :), projected_data_3d(2, :), projected_data_3d(3, :), 10, floor((train - 1) / 10) + 1, 'filled');
xlabel('PC1');
ylabel('PC2');
zlabel('PC3');
title('三维可视化');
colorbar;

