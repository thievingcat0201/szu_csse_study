%% 初始化
clear; clc;
reshaped_faces = []; % 创建一个矩阵

%% 加载数据
for i = 1:99 % 循环多少人
    for j = 1:20 % 每人多少个样本
        if (i < 10) % 输入图片自动转化为矩阵
            a = imread(strcat('C:\Users\27419\Desktop\AR_Gray_50by40\AR00', num2str(i), '-', num2str(j), '.tif')); % 构建图像地址
        else
            a = imread(strcat('C:\Users\27419\Desktop\AR_Gray_50by40\AR0', num2str(i), '-', num2str(j), '.tif'));
        end
        reshaped_faces = cat(3, reshaped_faces, double(a)); % 将图像堆叠在第三维度，并转换为 double 类型
    end
end

%% 划分训练集和测试集
test = []; % 定义测试数据组
train = []; % 定义训练数据组
for i = 0:99
    test = [test, 10 * i + 1:10 * i + 6]; % 提取每一张人脸前六张作为测试
    train = [train, 10 * i + 7:10 * i + 14]; % 提取每一张人脸的后14张作为训练
end
train_data = reshaped_faces(:, :, train); % 训练数据
test_data = reshaped_faces(:, :, test); % 测试数据

%% 求均值和中心化
mean_face = mean(train_data, 3); % 求训练脸的平均
centered_face = (train_data - mean_face); % 每一张脸减去平均脸

%% B2DPCA 降维
% 列方向 2DPCA
G_col = zeros(size(centered_face, 2), size(centered_face, 2));
for i = 1:size(centered_face, 3)
    G_col = G_col + centered_face(:, :, i)' * centered_face(:, :, i);
end
G_col = G_col / size(centered_face, 3);
[eigen_vectors_col, ~] = eig(G_col); % 特征向量和特征值
eigen_values_col = diag(eigen_vectors_col);
[~, index_col] = sort(eigen_values_col, 'descend');
sorted_eigen_vectors_col = eigen_vectors_col(:, index_col);

% 行方向 2DPCA
G_row = zeros(size(centered_face, 1), size(centered_face, 1));
for i = 1:size(centered_face, 3)
    G_row = G_row + centered_face(:, :, i) * centered_face(:, :, i)';
end
G_row = G_row / size(centered_face, 3);
[eigen_vectors_row, ~] = eig(G_row); % 特征向量和特征值
eigen_values_row = diag(eigen_vectors_row);
[~, index_row] = sort(eigen_values_row, 'descend');
sorted_eigen_vectors_row = eigen_vectors_row(:, index_row);

%% 任务 1：B2DPCA 人脸重构（显示三个人物的重构图像）
% 选择三个人物的索引（例如第1、第20、第40个人物）
person_indices = [1, 20, 40]; % 选择三个人物的索引
num_persons = length(person_indices); % 人物数量
index = 1; % 子图索引
figure;

% 遍历每个人物
for p = 1:num_persons
    person_idx = person_indices(p); % 当前人物的索引
    single_face = centered_face(:, :, person_idx); % 取出当前人物的第一张图像进行重构
    
    % 遍历不同维度
    for dimensionality = 20:20:40 % 以20维度开始逐步增加
        % 列方向投影
        eigen_faces_col = sorted_eigen_vectors_col(:, 1:dimensionality); % 取前 dimensionality 个列方向特征向量
        projected_face_col = single_face * eigen_faces_col; % 列方向投影，维度为 50×dimensionality
        
        % 行方向投影
        eigen_faces_row = sorted_eigen_vectors_row(:, 1:dimensionality); % 取前 dimensionality 个行方向特征向量
        projected_face_row = eigen_faces_row' * single_face; % 行方向投影，维度为 dimensionality×40
        
        % 重构图像
        rebuild_face = eigen_faces_row * projected_face_row + mean_face; % 重构图像，维度为 50×40
        
        % 显示重构图像
        subplot(num_persons, 4, index); % 子图布局：num_persons 行，4 列
        imshow(uint8(rebuild_face)); % 展示照片
        title(sprintf("Person %d, dim=%d", person_idx, dimensionality)); % 标题
        index = index + 1; % 依次增大索引
    end
end

%% 任务 2：B2DPCA 人脸识别
% 人脸识别
Y = []; % 保存识别率
max_dim_col = size(sorted_eigen_vectors_col, 2); % 列方向最大维度
max_dim_row = size(sorted_eigen_vectors_row, 2); % 行方向最大维度
for k = 1:6 % 设置 k 值
    for i = 10:10:min(max_dim_col, max_dim_row) % 测试不同维度，确保不超过最大维度
        % 列方向投影
        eigen_faces_col = sorted_eigen_vectors_col(:, 1:i); % 取前 i 个列方向特征向量
        projected_train_data_col = zeros(size(train_data, 1), i, size(train_data, 3));
        projected_test_data_col = zeros(size(test_data, 1), i, size(test_data, 3));
        for j = 1:size(train_data, 3)
            projected_train_data_col(:, :, j) = train_data(:, :, j) * eigen_faces_col; % 训练数据列方向投影
        end
        for j = 1:size(test_data, 3)
            projected_test_data_col(:, :, j) = test_data(:, :, j) * eigen_faces_col; % 测试数据列方向投影
        end
        
        % 行方向投影
        eigen_faces_row = sorted_eigen_vectors_row(:, 1:i); % 取前 i 个行方向特征向量
        projected_train_data = zeros(i, i, size(train_data, 3));
        projected_test_data = zeros(i, i, size(test_data, 3));
        for j = 1:size(train_data, 3)
            projected_train_data(:, :, j) = eigen_faces_row' * projected_train_data_col(:, :, j); % 训练数据行方向投影
        end
        for j = 1:size(test_data, 3)
            projected_test_data(:, :, j) = eigen_faces_row' * projected_test_data_col(:, :, j); % 测试数据行方向投影
        end

        % KNN 分类
        correct_predict_number = 0;
        for each_test_face_index = 1:size(projected_test_data, 3)
            distances = zeros(size(projected_train_data, 3), 1);
            for j = 1:size(projected_train_data, 3)
                distances(j) = norm(projected_train_data(:, :, j) - projected_test_data(:, :, each_test_face_index), 'fro');
            end
            [~, sorted_indices] = sort(distances); % 排序
            predict_label = mode(floor((train(sorted_indices(1:k)) - 1) / 10) + 1); % 预测标签
            real_label = floor((test(each_test_face_index) - 1) / 10) + 1; % 真实标签
            if predict_label == real_label
                correct_predict_number = correct_predict_number + 1;
            end
        end
        correct_rate = correct_predict_number / size(projected_test_data, 3); % 计算识别率
        Y = [Y, correct_rate]; % 保存识别率
    end
end

% 将 Y 重塑为 (max_dim/10) x 6 的矩阵
Y = reshape(Y, [], 6);

% 绘制识别率变化曲线图
figure;
hold on;
for k = 1:6
    plot(10:10:min(max_dim_col, max_dim_row), Y(:, k), '-o', 'DisplayName', sprintf('k=%d', k));
end
xlabel('维度');
ylabel('识别率');
title('不同维度下的识别率变化曲线');
legend show;
grid on;
hold off;

