clear;
% 人脸数据集的导入与数据处理框架
reshaped_faces = [];
database_name = "ORL"; % 可选项: "ORL", "AR", "FERET", "Yale"

%% 数据加载
switch database_name
    case "ORL"
        % ORL56_46数据集 (40人×10张)
        for i=1:40    
            for j=1:10       
                a = imread(sprintf('C:\\Users\\27419\\Desktop\\ORL56_46\\orl%d_%d.bmp', i, j));     
                b = double(reshape(a, 56*46, 1));        
                reshaped_faces = [reshaped_faces, b];  
            end
        end
        row = 56; column = 46;
        people_num = 40; pic_num_of_each = 10;
        train_num_each = 5; test_num_each = 5;
        
    case "AR"
        % AR数据集 (40人×10张)
        for i=1:40    
            for j=1:10       
                a = imread(sprintf('C:\\Users\\27419\\Desktop\\AR_Gray_50by40\\AR%02d-%d.tif', i, j));     
                b = double(reshape(a, 50*40, 1));        
                reshaped_faces = [reshaped_faces, b];  
            end
        end
        row = 50; column = 40;
        people_num = 40; pic_num_of_each = 10;
        train_num_each = 4; test_num_each = 6;
        
    case "FERET"
        % FERET数据集 (80人×7张)
        for i=1:80    
            for j=1:7       
                a = imread(sprintf('C:\\Users\\27419\\Desktop\\FERET_80\\ff%d_%d.tif', i, j));     
                b = double(reshape(a, 80*80, 1));        
                reshaped_faces = [reshaped_faces, b];  
            end
        end
        row = 80; column = 80;
        people_num = 80; pic_num_of_each = 7;
        train_num_each = 4; test_num_each = 3;
        
    case "Yale"
        % Yale数据集 (15人×11张)
        for i=1:15    
            for j=1:11
                a = imread(sprintf('F:\\学习\\大一学习\\计算机导论\\face10080\\subject%02d_%d.bmp', i, j)); 
                b = double(reshape(a, 100*80, 1));        
                reshaped_faces = [reshaped_faces, b];  
            end
        end
        row = 100; column = 80;
        people_num = 15; pic_num_of_each = 11;
        train_num_each = 1; test_num_each = 10;
end

test_sum = test_num_each * people_num;

%% PCA降维
mean_face = mean(reshaped_faces, 2);
centered_face = reshaped_faces - mean_face;

[U, S, ~] = svd(centered_face, 'econ');
eigen_values = diag(S).^2;

energy_ratio = cumsum(eigen_values)/sum(eigen_values);
n = find(energy_ratio >= 0.95, 1); 
fprintf('自动选择PCA维度: %d (保留%.2f%%能量)\n', n, energy_ratio(n)*100);

eigen_faces = U(:, 1:n);
projected_data = eigen_faces' * centered_face;

%% 回归算法比较
methods = {'线性回归', '岭回归', 'Lasso像素回归'};
accuracy = zeros(1, 3);

for method_idx = 1:3
    count_right = 0;
    
    for i = 0:people_num-1
        for k = train_num_each+1:pic_num_of_each
            test_sample = projected_data(:, i*pic_num_of_each + k);
            test_Y = reshaped_faces(:, i*pic_num_of_each + k)';
            distances = zeros(1, people_num);
            
            for j = 0:people_num-1
                train_set = projected_data(:, j*pic_num_of_each+1 : j*pic_num_of_each+train_num_each);
                
                switch method_idx
                    case 1 % 线性回归
                        w = pinv(train_set' * train_set) * train_set' * test_sample;
                        predicted = train_set * w;
                        distances(j+1) = norm(predicted - test_sample);
                        
                    case 2 % 岭回归
                        lambda = 0.1;
                        w = (train_set'*train_set + lambda*eye(train_num_each)) \ (train_set'*test_sample);
                        predicted = train_set * w;
                        distances(j+1) = norm(predicted - test_sample);
                        
                   case 3 % 优化后的Lasso回归
    X_train = train_set';  % [train_num_each × n_features]
    X_test = test_sample'; % [1 × n_features]
    
    % 使用所有训练样本构建Y（更高效的实现）
    Y = reshaped_faces(:, j*pic_num_of_each+1:j*pic_num_of_each+train_num_each)';
    
    % 并行化Lasso回归（需要Parallel Computing Toolbox）
    pred_pixels = zeros(1, size(Y,2));
    parfor f = 1:size(Y,2)
        [w, fitInfo] = lasso(X_train, Y(:,f), 'Lambda', 0.1);
        pred_pixels(f) = X_test * w + fitInfo.Intercept;
    end
    
    % 计算距离
    test_Y = reshaped_faces(:, i*pic_num_of_each + k)';
    distances(j+1) = norm(pred_pixels - test_Y);
                
                case 4 % 梯度下降岭回归
    X_train = train_set';  % [train_num_each × n_features]
    y_train = test_sample; % 使用测试样本作为目标
    
    % 超参数设置
    lambda = 0.1;
    learning_rate = 0.01;
    max_iters = 1000;
    
    [w, ~] = ridge_gradient_descent(X_train, y_train, lambda, learning_rate, max_iters);
    
    predicted = train_set * w;
    distances(j+1) = norm(predicted - test_sample);
    case 5 % WNNR
    train_data = train_set'; % [n_train × n_features]
    test_data = test_sample'; % [1 × n_features]
    
    % 参数设置
    k = min(10, train_num_each); % 近邻数不超过训练样本数
    lambda = 0.01;
    
    [pred, ~] = WNNR(train_data, mean(train_data,2), test_data, k, lambda);
    distances(j+1) = norm(pred - test_data');

end
            end
            
            [~, pred_label] = min(distances);
            if pred_label == i+1
                count_right = count_right + 1;
            end
        end
    end
    
    accuracy(method_idx) = count_right / test_sum;
    fprintf('%s 识别率: %.2f%%\n', methods{method_idx}, accuracy(method_idx)*100);
end

%% 可视化结果
figure('Position', [100, 100, 800, 400]);
subplot(1,2,1);
bar(accuracy * 100);
set(gca, 'XTickLabel', methods);
ylabel('识别率 (%)');
title('不同回归算法性能比较');
ylim([0 100]);
grid on;

subplot(1,2,2);
rand_person = randi(people_num);
rand_img = randi(train_num_each);
original_face = reshape(reshaped_faces(:, (rand_person-1)*pic_num_of_each + rand_img), row, column);
reconstructed_face = mean_face + eigen_faces * projected_data(:, (rand_person-1)*pic_num_of_each + rand_img);
reconstructed_face = reshape(reconstructed_face, row, column);
imshowpair(mat2gray(original_face), mat2gray(reconstructed_face), 'montage');
title(sprintf('原始 vs 重建 (人物%d)', rand_person));

%% 显示特征脸
figure('Name', '特征脸示例');
for i = 1:9
    subplot(3,3,i);
    ef = reshape(eigen_faces(:,i), row, column);
    imshow(mat2gray(ef));
    title(sprintf('特征脸 %d', i));
end